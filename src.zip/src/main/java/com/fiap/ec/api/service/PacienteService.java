package com.fiap.ec.api.service;

import com.fiap.ec.api.domain.paciente.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PacienteService {

    @Autowired
    private PacienteRepository repository;

    @Transactional
    public Paciente cadastrar(DadosCadastroPaciente dados) {
        var paciente = new Paciente(dados);
        return repository.save(paciente);
    }

    public List<DadosListagemPaciente> listarAtivos() {
        return repository.findAllByAtivoTrue().stream().map(DadosListagemPaciente::new).toList();
    }

    @Transactional
    public Paciente atualizar(DadosAtualizacaoPaciente dados) {
        var paciente = repository.getReferenceById(dados.id());
        paciente.atualizarInformacoes(dados);
        return paciente;
    }

    @Transactional
    public void excluir(Long id) {
        // Exclusão lógica (soft delete)
        var paciente = repository.getReferenceById(id);
        paciente.inativar();
    }
}
