package com.fiap.ec.api.controller;

import com.fiap.ec.api.domain.paciente.DadosAtualizacaoPaciente;
import com.fiap.ec.api.domain.paciente.DadosCadastroPaciente;
import com.fiap.ec.api.domain.paciente.DadosListagemPaciente;
import com.fiap.ec.api.service.PacienteService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pacientes")
public class PacienteController {

    @Autowired
    private PacienteService service;

    @PostMapping
    public ResponseEntity cadastrar(@RequestBody @Valid DadosCadastroPaciente dados) {
        service.cadastrar(dados);
        return ResponseEntity.ok().build(); // Em produção recomenda-se retornar 201 Created
    }

    @GetMapping
    public ResponseEntity<List<DadosListagemPaciente>> listar() {
        var lista = service.listarAtivos();
        return ResponseEntity.ok(lista);
    }

    @PutMapping
    public ResponseEntity atualizar(@RequestBody @Valid DadosAtualizacaoPaciente dados) {
        service.atualizar(dados);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity excluir(@PathVariable Long id) {
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }
}